//
//  UIButton+SnapAdditions.h
//  Snap
//
//  Created by Ray Wenderlich on 5/24/12.
//  Copyright (c) 2012 Hollance. All rights reserved.
//

@interface UIButton (SnapAdditions)

- (void)rw_applySnapStyle;

@end